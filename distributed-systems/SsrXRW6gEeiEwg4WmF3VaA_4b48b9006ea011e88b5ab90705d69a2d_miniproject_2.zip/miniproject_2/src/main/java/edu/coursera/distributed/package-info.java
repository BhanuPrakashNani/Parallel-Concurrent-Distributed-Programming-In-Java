/**
 * Source code from the Java Distributed Programming Coursera course.
 */
package edu.coursera.distributed;
